package com.example.util

import android.content.Context
import android.content.Intent

/** No-op in the independent, offline-only V2 preview. */
fun configureAppCheck(context: Context, intent: Intent?) = Unit
