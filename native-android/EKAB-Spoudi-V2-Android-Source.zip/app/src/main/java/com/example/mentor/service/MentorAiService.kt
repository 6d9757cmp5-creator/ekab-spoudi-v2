package com.example.mentor.service

import com.example.mentor.models.TutorMessage

/**
 * V2 independent preview intentionally does not connect to the original AI/Firebase project.
 * Configure a brand-new secure backend before enabling any AI functionality.
 */
class MentorAiService {
    suspend fun generateClinicalResponse(
        query: String,
        facultyName: String,
        facultySpecialty: String,
        onChunk: (String) -> Unit
    ): TutorMessage {
        val text = "Ο ζωντανός AI Καθηγητής δεν έχει ενεργοποιηθεί στη δοκιμαστική, " +
            "ανεξάρτητη έκδοση ΕΚΑΒ Σπουδή V2. Τα εκπαιδευτικά δεδομένα και " +
            "οι υπόλοιπες ενότητες της εφαρμογής παραμένουν διαθέσιμα τοπικά."
        onChunk(text)
        return TutorMessage(sender = "mentor", text = text, citations = emptyList())
    }
}
