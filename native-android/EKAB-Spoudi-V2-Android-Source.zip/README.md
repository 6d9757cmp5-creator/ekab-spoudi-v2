# ΕΚΑΒ Σπουδή V2 — Ανεξάρτητο native Android project

Προέρχεται απευθείας από το **αρχικό Android ZIP της 29/10/2026**, με το εκπαιδευτικό περιεχόμενο και τις οθόνες του. Όνομα εφαρμογής: **ΕΚΑΒ Σπουδή V2**, `applicationId`: **com.ekabspoudi.v2** ώστε να συνυπάρχει με τυχόν άλλη Android έκδοση.

## Ασφάλεια και ανεξαρτησία
Το παλιό `google-services.json`, το reCAPTCHA configuration και οι συνδέσεις Firebase/App Check/AI αφαιρέθηκαν. Ο AI Mentor εμφανίζει **σαφές μήνυμα μη διαθεσιμότητας** αντί να συνδέεται με παλιό project. Δεν γίνεται συγχρονισμός προσωπικών δεδομένων. Οι ιατρικές εκπαιδευτικές απαντήσεις δεν έχουν πιστοποιηθεί ανεξάρτητα στο πλαίσιο αυτής της μεταφοράς.

## Build
- Άνοιγμα με πρόσφατο Android Studio και εγκατεστημένο Android SDK Platform 36.1.
- Το GitHub Actions `.github/workflows/android-apk.yml` μπορεί να τρέξει **μόνο σε ολοκαίνουργιο repo `ekab-spoudi-v2`**, όχι στο παλιό `ekab-spoudi`.
- Χρησιμοποιεί Gradle 9.3.1 (τα gradle-wrapper.jar και gradlew δεν υπάρχουν στο export) και JDK 17. Το Android Studio εγκαθιστά/ρυθμίζει τις εξαρτήσεις του.
- Έπειτα το GitHub Actions παράγει ένα debug APK στις καρτέλες Artifacts όταν ο πραγματικός build περάσει. Δεν έχει δοκιμαστεί compile εδώ επειδή δεν είναι εγκατεστημένο Android SDK/Gradle.
- Για παραγωγή υπογεγραμμένου release APK απαιτείται ανεξάρτητο release keystore, που δεν δημοσιεύεται στο repository.

## iOS
Το Kotlin/Jetpack Compose Android source δεν παράγει IPA. Χρειάζεται ξεχωριστή iOS υλοποίηση και Apple signing. Το web/PWA preview λειτουργεί σε iPhone μέσω Safari/HTTPS.
